class API_STRING {
  //User API string
  static User_Search = "/Users/Search";
  static User_Insert = "/Users/Insert";
  static User_Update = "/Users/Update";
  static User_Delete = "/Users/Delete";
  static User_Delete_ADMIN = "/Users/DeleteEX";
  static LoginServerTypeOne = "/Login-Server-Type-One";
  static LoginServerForgetPassword = "/Login-Server-forget-password";
  static LoginServerUpdatePassword = "/Login-Server-update-password";
}
module.exports = API_STRING;
