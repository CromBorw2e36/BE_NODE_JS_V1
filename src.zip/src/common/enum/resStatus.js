class RES_STATUS {
  static SUCCESS = 1;
  static ERROR = 0;
  static EXITS = 2;
  static NOTFOUND = -1;
  static SERVER_ERROR = -999;
}

module.exports = RES_STATUS;
