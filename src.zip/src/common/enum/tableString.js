class TABLE_NAME {
  static USER = "user";
}

module.exports = TABLE_NAME;
